<?php

# Easy starter :)

/* Init database
-- Table structure for table `haxorz_memberz`
--

CREATE TABLE IF NOT EXISTS `haxorz_memberz` (
  `login` varchar(15) collate utf8_unicode_ci NOT NULL,
  `password` varchar(65) collate utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
*/

define('BDD_HOST', 'localhost');
define('BDD_USER', 'FIXME');
define('BDD_PASSWORD', 'FIXME');
define('BDD_DATABASE', 'FIXME');

define('CHALLENGE_PASSWORD', 'FIXME');

require_once dirname(__FILE__).'/inc/lang.php';
require_once dirname(__FILE__).'/inc/header.php';

$auth = FALSE;

if (isset($_POST['login'], $_POST['password']) && is_string($_POST['login']) && is_string($_POST['password']))
{
	$con = mysql_connect(BDD_HOST, BDD_USER, BDD_PASSWORD);
	mysql_select_db(BDD_DATABASE, $con);

	$query = sprintf("SELECT * FROM haxorz_memberz WHERE login = '%s' AND password = MD5('%s')",
		mysql_real_escape_string($_POST['login']),
		$_POST['password']
	);

	$sql = mysql_query($query);

	if (@mysql_num_rows($sql) == 1)
		$auth = TRUE;
	 else
		printf(fail);
}

if ($auth)
{
	printf(greetz, CHALLENGE_PASSWORD);
}
else
{
	echo <<< EOT
		<form method="post" action="">
		<table style="margin-left : auto; margin-right : auto;">
			<tr><td><strong>Login</strong></td><td><input type="text" size="15" name="login" /></td></tr>
			<tr><td><strong>Password<strong></td><td><input type="password" size="15" name="password" /></td></tr>
			<tr><td colspan="2" style="text-align: center;"><input type="submit" /></td></tr>
		</table>
		</form>
EOT;

}

require_once dirname(__FILE__).'/inc/footer.php';

?>
