<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
  <head>
	<title>W3Challs Hacking Challenge: <?php echo TITLE; ?></title>
  	<meta name="language" content="<?php echo $lang; ?>" />
  	<meta name="copyright" content="w3challs" />
  	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-language" content="<?php echo $lang; ?>" />
  </head>
<body>
<div style="text-align: center;">
<img src="/images/auth.jpg" alt="" /><br />
<h1><?php echo auth; ?></h1>
