<?php

define('TITLE', 'Une faille de base');
define('fail', '<div style="text-align: center;color: #ff000c;">Mauvais login/password</div>');
define('greetz', '<div style="text-align: center;color: #35ae00;">Bravo, le mot de passe est <strong>%s</strong></div>');
define('auth', 'Authentification');

?>
