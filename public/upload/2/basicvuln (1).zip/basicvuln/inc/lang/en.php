<?php

define('TITLE', 'A basic vulnerability');
define('fail', '<div style="text-align: center;color: #ff000c;">Wrong login/password</div>');
define('greetz', '<div style="text-align: center;color: #35ae00;">Well done, password is <strong>%s</strong></div>');
define('auth', 'Authentication');

?>
