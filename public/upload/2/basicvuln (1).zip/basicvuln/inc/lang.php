<?php

$lang = (isset ($_COOKIE['lang']) && $_COOKIE['lang'] == 'en') ? 'en' : 'fr';  
require_once('lang/'.$lang.'.php');

?> 
