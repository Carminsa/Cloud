Home
====

This **TinyMCE** allows developers to quickly add the TinyMCE editor to their applications.

Requirements
------------

* CakePHP 2.5+
* PHP 5.2.8+

Documentation
-------------

* [Overview](Documentation/Overview.md)
* [Installation](Documentation/Installation.md)
* [Setup](Documentation/Setup.md)
* [Examples](Documentation/Examples.md)
