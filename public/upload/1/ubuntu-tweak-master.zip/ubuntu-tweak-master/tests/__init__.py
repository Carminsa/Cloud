from ubuntutweak.common.debug import enable_debugging

enable_debugging()
