PK_ACTION_TWEAK = 'com.ubuntu-tweak.daemon.tweak'
PK_ACTION_CLEAN = 'com.ubuntu-tweak.daemon.clean'
PK_ACTION_SOURCE = 'com.ubuntu-tweak.daemon.edit-sources'
