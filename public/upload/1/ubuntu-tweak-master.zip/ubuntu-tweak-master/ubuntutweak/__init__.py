VERSION = (0, 8, 8)
__version__ = '.'.join(map(str, VERSION))
